<?php
    echo 'Hola soy la accion'.$_POST['nombre']. " ".$_POST['apellidos'];
    include_once 'index.php';;
?>

