<?php
    require 'libs/FrontController.php';
    FrontController::main();
?>

<!--<html>
    
    <body>
        <form action="accion.php" method="post">
            <div>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre"/>                  
            </div>
            <div>
                <label for="apellidos">Apellidos:</label>
                <input type="text" id="apellidos" name="apellidos"/>                  
            </div>
            <div>
                <input type="submit" value="Enviar"/>                  
            </div>            
        </form>
    </body>
    
</html>-->



<?php
    
//    include_once 'Persona.php';
//    echo 'Hola<br>';
//    $persona=new Persona("Nelson", "Mendez");
//    echo 'Persona '.$persona;
?>

