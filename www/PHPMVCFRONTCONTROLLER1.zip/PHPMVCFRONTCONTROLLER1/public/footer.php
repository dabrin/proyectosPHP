               
            </section>
            <aside>
                <a href="https://mediacionvirtual.ucr.ac.cr/login/index.php" target="_blank">
                    <img src="public/img/mediacionvirtual.png" alt="Mediacion virtual"/>
                </a>
            </aside>
        </section>
        <footer>
            Ejemplo HTML5, CSS3 y JavaScript
        </footer>
        
    </body>
</html>





