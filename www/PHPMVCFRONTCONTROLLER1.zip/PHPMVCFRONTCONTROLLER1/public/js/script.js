function saludarArchivo(){
    alert("Saludo desde archivo");
}

function leerValores(){
    var nombre=document.getElementById('nombre').value
    document.getElementById('resultado'+1).innerHTML=nombre
    
}