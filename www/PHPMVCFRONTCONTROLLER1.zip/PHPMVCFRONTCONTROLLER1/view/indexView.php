<?php
    include_once 'public/header.php';
    
?>

 <article id="descripcion">
                    <p>
                        Esta es la descripcion Esta es la descripcion
                        Esta es la descripcion Esta es la descripcion
                        Esta es la descripcion Esta es la descripcion
                        Esta es la descripcion Esta es la descripcion
                        Esta es la descripcion Esta es la descripcion
                        Esta es la descripcion Esta es la descripcion
                    </p>
                    <form>
                        <input type="text" id="nombre" name="nombre" required/>
                        <input type="submit" id="enviar" name="enviar"/>
                    </form>
                </article> 

<?php
    include_once 'public/footer.php';
?>


